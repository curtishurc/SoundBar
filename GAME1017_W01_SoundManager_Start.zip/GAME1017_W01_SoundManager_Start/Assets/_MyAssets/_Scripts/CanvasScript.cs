using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CanvasScript : MonoBehaviour
{
    void Start()
    {
        // Fill in for lab. Add all sounds to SoundManager.
        
    }

    public void PlaySFX(string soundKey)
    {
        //SoundManager.PlaySound(soundKey);
    }

    public void PlayMusic(string soundKey)
    {
        //SoundManager.PlayMusic(soundKey);
    }
}
