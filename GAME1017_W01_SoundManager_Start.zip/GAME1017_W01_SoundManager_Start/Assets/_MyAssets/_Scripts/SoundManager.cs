using System.Collections.Generic;
using UnityEngine;

public static class SoundManager
{
    public enum SoundType
    {
        SOUND_SFX,
        SOUND_MUSIC
    }

    // Create Dictionary for sfx.
    // Create Dictionary for music.
    // Create AudioSource for sfx.
    // Create AudioSource for music.

    static SoundManager() // Static constructor. Gets called the first time the class is accessed.
    {
        Initialize();
    }

    // Initialize the SoundManager. I just put this functionality here instead of in the static constructor.
    private static void Initialize()
    {
        // Create a new GameObject to hold the AudioSource
        GameObject soundManagerObject = new GameObject("SoundManager");
        
        // Fill in for lab.
    }

    // Add a sound to the dictionary.
    public static void AddSound(string soundKey, AudioClip audioClip, SoundType soundType)
    {
        // Fill in for lab.
    }

    // Play a sound by key interface.
    public static void PlaySound(string soundKey)
    {
        // Fill in for lab.
    }

    // Play music by key interface.
    public static void PlayMusic(string soundKey)
    {
        // Fill in for lab.
    }

    // Play utility.
    private static void Play(string soundKey, SoundType soundType)
    {
        // Fill in for lab.
    }

    private static void SetTargetsByType(SoundType soundType, out Dictionary<string, AudioClip> targetDictionary, out AudioSource targetSource)
    {
        // Fill in for lab.
    }
    private static Dictionary<string, AudioClip> GetDictionaryByType(SoundType soundType)
    {
        // Fill in for lab.
    }
}